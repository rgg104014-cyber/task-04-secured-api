require("dotenv").config();

const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { z } = require("zod");
const pool = require("./db");

const app = express();
app.use(express.json({ limit: "20kb" }));

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  throw new Error("JWT_SECRET is required");
}

class AppError extends Error {
  constructor(message, statusCode = 500, details) {
    super(message);
    this.statusCode = statusCode;
    this.details = details;
  }
}

const registerSchema = z.object({
  name: z.string().trim().min(2).max(100),
  email: z.string().trim().email().max(255),
  password: z.string().min(8).max(72)
});

const loginSchema = z.object({
  email: z.string().trim().email().max(255),
  password: z.string().min(1).max(72)
});

const noteSchema = z.object({
  title: z.string().trim().min(1).max(150),
  content: z.string().trim().max(5000).default("")
});

function validate(schema, body) {
  const result = schema.safeParse(body);
  if (!result.success) {
    throw new AppError("Validation failed", 400, result.error.issues.map(issue => ({
      field: issue.path.join("."),
      message: issue.message
    })));
  }
  return result.data;
}

function signToken(user) {
  return jwt.sign(
    { sub: String(user.id), email: user.email },
    JWT_SECRET,
    { expiresIn: "1h" }
  );
}

function requireAuth(req, res, next) {
  const header = req.get("authorization") || "";
  const [scheme, token] = header.split(" ");

  if (scheme !== "Bearer" || !token) {
    return next(new AppError("Authentication token required", 401));
  }

  try {
    const payload = jwt.verify(token, JWT_SECRET);
    if (!payload.sub || !/^[1-9]\d*$/.test(String(payload.sub))) {
      throw new Error("Invalid token subject");
    }
    req.user = { id: Number(payload.sub), email: payload.email };
    next();
  } catch {
    next(new AppError("Invalid or expired token", 401));
  }
}

app.get("/", (req, res) => {
  res.json({ success: true, message: "Secured API is running" });
});

app.post("/auth/register", async (req, res, next) => {
  try {
    const { name, email, password } = validate(registerSchema, req.body);
    const passwordHash = await bcrypt.hash(password, 12);

    try {
      const result = await pool.query(
        `INSERT INTO users (name, email, password_hash)
         VALUES ($1, LOWER($2), $3)
         RETURNING id, name, email, created_at`,
        [name, email, passwordHash]
      );
      const user = result.rows[0];
      res.status(201).json({
        success: true,
        data: { user, token: signToken(user) }
      });
    } catch (error) {
      if (error.code === "23505") {
        return next(new AppError("Email is already registered", 409));
      }
      next(error);
    }
  } catch (error) {
    next(error);
  }
});

app.post("/auth/login", async (req, res, next) => {
  try {
    const { email, password } = validate(loginSchema, req.body);
    const result = await pool.query(
      "SELECT id, name, email, password_hash FROM users WHERE email = LOWER($1)",
      [email]
    );
    const user = result.rows[0];

    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
      throw new AppError("Invalid email or password", 401);
    }

    res.json({
      success: true,
      data: {
        user: { id: user.id, name: user.name, email: user.email },
        token: signToken(user)
      }
    });
  } catch (error) {
    next(error);
  }
});

app.get("/notes", requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT id, user_id, title, content, created_at
       FROM notes WHERE user_id = $1 ORDER BY id`,
      [req.user.id]
    );
    res.json({ success: true, data: result.rows });
  } catch (error) {
    next(error);
  }
});

app.post("/notes", requireAuth, async (req, res, next) => {
  try {
    const { title, content } = validate(noteSchema, req.body);
    const result = await pool.query(
      `INSERT INTO notes (user_id, title, content)
       VALUES ($1, $2, $3)
       RETURNING id, user_id, title, content, created_at`,
      [req.user.id, title, content]
    );
    res.status(201).json({ success: true, data: result.rows[0] });
  } catch (error) {
    next(error);
  }
});

app.get("/notes/:id", requireAuth, async (req, res, next) => {
  try {
    if (!/^[1-9]\d*$/.test(req.params.id)) {
      throw new AppError("Invalid note ID", 400);
    }
    const result = await pool.query(
      `SELECT id, user_id, title, content, created_at
       FROM notes WHERE id = $1 AND user_id = $2`,
      [Number(req.params.id), req.user.id]
    );
    if (result.rowCount === 0) {
      throw new AppError("Note not found", 404);
    }
    res.json({ success: true, data: result.rows[0] });
  } catch (error) {
    next(error);
  }
});

app.delete("/notes/:id", requireAuth, async (req, res, next) => {
  try {
    if (!/^[1-9]\d*$/.test(req.params.id)) {
      throw new AppError("Invalid note ID", 400);
    }
    const result = await pool.query(
      "DELETE FROM notes WHERE id = $1 AND user_id = $2 RETURNING id",
      [Number(req.params.id), req.user.id]
    );
    if (result.rowCount === 0) {
      throw new AppError("Note not found", 404);
    }
    res.json({ success: true, message: "Note deleted successfully" });
  } catch (error) {
    next(error);
  }
});

app.use((req, res, next) => next(new AppError("Route not found", 404)));

app.use((err, req, res, next) => {
  if (res.headersSent) return next(err);

  if (err instanceof SyntaxError && err.status === 400 && "body" in err) {
    return res.status(400).json({ success: false, error: "Invalid JSON request body" });
  }

  const status = err.statusCode || 500;
  if (status >= 500) console.error(err.message);

  res.status(status).json({
    success: false,
    error: status >= 500 ? "Internal server error" : err.message,
    ...(err.details ? { details: err.details } : {})
  });
});

module.exports = app;
