# Task 04 — Secured API

A Node.js REST API featuring JWT authentication, bcrypt password hashing, PostgreSQL storage, user-owned notes, and automated integration tests.

## Requirements
- Node.js 18+
- PostgreSQL

## Setup

1. Install dependencies:

   ```bash
   npm install
   ```

2. Create two empty PostgreSQL databases: `task4db` and `task4_test`.

3. Copy `.env.example` to `.env` and set `DATABASE_URL`, `TEST_DATABASE_URL`, and a long random `JWT_SECRET`. For tests, create `.env.test` with:

   ```env
   TEST_DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@localhost:5432/task4_test
   JWT_SECRET=test-only-secret-change-me
   ```

   Do not commit `.env` or `.env.test`.

4. Apply development migrations:

   ```bash
   npm run migrate
   ```

5. Start the API:

   ```bash
   npm start
   ```

6. Run the integration tests:

   ```bash
   npm test
   ```

Tests use `TEST_DATABASE_URL` and clear the test database tables before each test. **Use a separate disposable test database**; never point it at production data. Tests apply the SQL migrations, so the test database should be empty the first time.

## Endpoints

| Method | Endpoint | Auth | Purpose |
|---|---|---|---|
| POST | `/auth/register` | No | Register and receive a token |
| POST | `/auth/login` | No | Log in and receive a token |
| GET | `/notes` | Yes | List the signed-in user's notes |
| POST | `/notes` | Yes | Create a note for the signed-in user |
| GET | `/notes/:id` | Yes | Read an owned note |
| DELETE | `/notes/:id` | Yes | Delete an owned note |

For protected endpoints, send `Authorization: Bearer YOUR_TOKEN`.

## Example registration

`POST /auth/register`

```json
{
  "name": "Alice Example",
  "email": "alice@example.com",
  "password": "StrongPass123"
}
```

## Security decisions
- Passwords are hashed with bcrypt; plaintext passwords are never stored.
- JWTs expire after one hour.
- SQL values use PostgreSQL parameter placeholders.
- Notes queries check both note ID and authenticated user ID.
- Error responses do not expose stack traces.
- Validation and database errors return JSON with appropriate HTTP status codes.

## Tests
The Jest/Supertest suite covers registration, duplicate emails, validation failures, login success/failure, missing tokens, owner access, cross-user access denial, create/delete flows, and stack-trace leakage.

## Rebuild from scratch
Create a fresh empty database, set `DATABASE_URL`, then run `npm run migrate`. For tests, configure a separate empty database in `TEST_DATABASE_URL` and run `npm test`.
