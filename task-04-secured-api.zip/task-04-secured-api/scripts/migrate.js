require("dotenv").config();
const fs = require("fs");
const path = require("path");
const pool = require("../db");

async function runMigrations() {
  const client = await pool.connect();
  try {
    await client.query("CREATE TABLE IF NOT EXISTS schema_migrations (filename VARCHAR(255) PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW())");
    const dir = path.join(__dirname, "..", "migrations");
    const files = fs.readdirSync(dir).filter(f => f.endsWith(".sql")).sort();

    for (const file of files) {
      const found = await client.query(
        "SELECT filename FROM schema_migrations WHERE filename = $1",
        [file]
      );
      if (found.rowCount) {
        console.log(`Already applied: ${file}`);
        continue;
      }

      await client.query("BEGIN");
      try {
        const sql = fs.readFileSync(path.join(dir, file), "utf8");
        await client.query(sql);
        await client.query(
          "INSERT INTO schema_migrations (filename) VALUES ($1)",
          [file]
        );
        await client.query("COMMIT");
        console.log(`Applied: ${file}`);
      } catch (error) {
        await client.query("ROLLBACK");
        throw error;
      }
    }
  } finally {
    client.release();
  }
}

if (require.main === module) {
  runMigrations()
    .catch(error => {
      console.error("Migration failed:", error.message);
      process.exitCode = 1;
    })
    .finally(() => pool.end());
}

module.exports = { runMigrations };
