const path = require("path");
require("dotenv").config({ path: path.join(__dirname, "..", ".env.test") });

if (!process.env.TEST_DATABASE_URL) {
  throw new Error("Set TEST_DATABASE_URL in .env.test before running tests");
}
process.env.NODE_ENV = "test";
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL;
process.env.JWT_SECRET = process.env.JWT_SECRET || "test-only-secret-change-me";

const request = require("supertest");
const pool = require("../db");
const app = require("../app");
const { runMigrations } = require("../scripts/migrate");

describe("secured API", () => {
  let aliceToken;
  let bobToken;
  let aliceNoteId;

  beforeAll(async () => {
    await runMigrations();
  });

  beforeEach(async () => {
    await pool.query("TRUNCATE notes, users RESTART IDENTITY CASCADE");
    const alice = await register("Alice Example", "alice@example.com");
    const bob = await register("Bob Example", "bob@example.com");
    expect(alice.status).toBe(201);
    expect(bob.status).toBe(201);
    aliceToken = alice.body.data.token;
    bobToken = bob.body.data.token;

    const note = await request(app)
      .post("/notes")
      .set("Authorization", `Bearer ${aliceToken}`)
      .send({ title: "Alice's note", content: "Private content" });
    aliceNoteId = note.body.data.id;
  });

  afterAll(async () => {
    await pool.end();
  });

  test("registers a user and returns a token without a password hash", async () => {
    const response = await register("Charlie Example", "charlie@example.com");
    expect(response.status).toBe(201);
    expect(response.body.data.token).toBeTruthy();
    expect(response.body.data.user.password_hash).toBeUndefined();
  });

  test("rejects duplicate registration emails", async () => {
    const response = await register("Alice Example", "alice@example.com");
    expect(response.status).toBe(409);
  });

  test("rejects invalid registration data", async () => {
    const response = await request(app).post("/auth/register").send({
      name: "A",
      email: "not-an-email",
      password: "short"
    });
    expect(response.status).toBe(400);
    expect(response.body.details).toBeDefined();
  });

  test("logs in with correct credentials", async () => {
    const response = await request(app).post("/auth/login").send({
      email: "alice@example.com",
      password: "StrongPass123"
    });
    expect(response.status).toBe(200);
    expect(response.body.data.token).toBeTruthy();
  });

  test("rejects an incorrect password", async () => {
    const response = await request(app).post("/auth/login").send({
      email: "alice@example.com",
      password: "WrongPassword123"
    });
    expect(response.status).toBe(401);
  });

  test("rejects requests without a token", async () => {
    const response = await request(app).get("/notes");
    expect(response.status).toBe(401);
  });

  test("allows a user to list only their own notes", async () => {
    const response = await request(app)
      .get("/notes")
      .set("Authorization", `Bearer ${aliceToken}`);
    expect(response.status).toBe(200);
    expect(response.body.data).toHaveLength(1);
    expect(response.body.data[0].title).toBe("Alice's note");
  });

  test("allows the owner to read their note", async () => {
    const response = await request(app)
      .get(`/notes/${aliceNoteId}`)
      .set("Authorization", `Bearer ${aliceToken}`);
    expect(response.status).toBe(200);
    expect(response.body.data.user_id).toBe(1);
  });

  test("rejects another user trying to read a note", async () => {
    const response = await request(app)
      .get(`/notes/${aliceNoteId}`)
      .set("Authorization", `Bearer ${bobToken}`);
    expect(response.status).toBe(404);
  });

  test("rejects another user trying to delete a note", async () => {
    const response = await request(app)
      .delete(`/notes/${aliceNoteId}`)
      .set("Authorization", `Bearer ${bobToken}`);
    expect(response.status).toBe(404);

    const stillExists = await request(app)
      .get(`/notes/${aliceNoteId}`)
      .set("Authorization", `Bearer ${aliceToken}`);
    expect(stillExists.status).toBe(200);
  });

  test("creates and deletes an owned note", async () => {
    const created = await request(app)
      .post("/notes")
      .set("Authorization", `Bearer ${bobToken}`)
      .send({ title: "Bob's note", content: "Hello" });
    expect(created.status).toBe(201);

    const deleted = await request(app)
      .delete(`/notes/${created.body.data.id}`)
      .set("Authorization", `Bearer ${bobToken}`);
    expect(deleted.status).toBe(200);
  });

  test("does not expose stack traces in error responses", async () => {
    const response = await request(app).get("/missing-route");
    expect(response.status).toBe(404);
    expect(JSON.stringify(response.body)).not.toContain(" at ");
    expect(response.body.stack).toBeUndefined();
  });
});
